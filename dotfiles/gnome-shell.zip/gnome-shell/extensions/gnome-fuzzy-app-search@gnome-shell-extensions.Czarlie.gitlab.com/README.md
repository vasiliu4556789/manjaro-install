GNOME Fuzzy App Search
==================

Forked from [https://github.com/fffilo/gnome-fuzzy-search](https://github.com/fffilo/gnome-fuzzy-search)

[Fuzzy](https://en.wikipedia.org/wiki/Approximate_string_matching) application search results for [Gnome Search](https://developer.gnome.org/SearchProvider/).

## How It Works

The plugin injects its own callback to `getResultSet` method in each registrated provider which appends new search results.
This means that it does not change default result set, just adds new results to existing ones.

The search query is split up into words and levenshtein distances to the words in the app names are calculated, scored and used to display fuzzy search results.

Keep in mind that although [the extension this is forked from](https://github.com/fffilo/gnome-fuzzy-search) plans to extend more search providers,
this will probably only ever support applications. The results of this application are even more fuzzy than the original one's (at the expense of some processing).

##### Fuzzy Search Disabled
![fuzzy search disabled](screenshot_before.png "Fuzzy Search Disabled")

##### Fuzzy Search Enabled
![fuzzy search enabled](screenshot_after.png "Fuzzy Search Enabled")

## Installation

- build and install from source
    - download source from [GitHub](https://gitlab.com/Czarlie/gnome-fuzzy-app-search) (clone repository or download zip)
    - from `gnome-fuzzy-app-search` directory execute `make install`
    - press `Alt`+`F2` and enter `r` and press `Enter` to reload extensions
